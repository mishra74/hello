const express =require('express');
const route=express.Router();
const controller=require('../controller/controller');
const services = require('../services/render');
var uploadModel=require('../model/imgmodel');
var multer = require('multer');
const path = require('path');
const bodyparser=require('body-parser');
var fs= require('fs');



route.use(bodyparser.urlencoded({extended:true}))





//route.get('/',services.homeRoutes);
//route.get('/',services.add_user);
//route.get('/',services.update_user);
//route.use('/static',express.static(path.join(__dirname+"./public/")))
var storage = multer.diskStorage({
	
     destination:"images",

	 filename:(req, file, cd) =>{

		cd(null, file.fieldname + "_" + Date.now()+file.originalname);
     	}	
    

});
var upload= multer({storage:storage});
   
     










//file uploading
route.post('/api/upload',upload.single('img'), function(req,res,next){
     var imageFile=req.file.filename

var success=req.file.filename + "uploaded successfully";

var imgDetails=new uploadModel({
img:imageFile
});
imgDetails.save(function(err,doc){
     if(err) throw err;
res.render('admin.js',{title: 'Upload File',success:success});
});
});

route.get('/api/image',controller.find_image);



route.post('/api/users',controller.create);
route.get('/api/user',controller.find);

route.post('/api/headline-one',controller.H_one);
route.get('/api/headline-one',controller.find_H_one);

route.post('/api/headline-two',controller.H_two);
route.get('/api/headline-two',controller.find_H_two);

route.post('/api/headline-three',controller.H_three);
route.get('/api/headline-three',controller.find_H_three);

route.post('/api/headline-four',controller.H_four);
route.get('/api/headline-four',controller.find_H_four);

route.post('/api/headline-five',controller.H_five);
route.get('/api/headline-five',controller.find_H_five);

route.post('/api/headline-six',controller.H_six);
route.get('/api/headline-six',controller.find_H_six);

route.post('/api/headline-seven',controller.H_seven);
route.get('/api/headline-seven',controller.find_H_seven);

route.post('/api/headline-eight',controller.H_eight);
route.get('/api/headline-eight',controller.find_H_eight);

route.post('/api/headline-nine',controller.H_nine);
route.get('/api/headline-nine',controller.find_H_nine);

route.post('/api/headline-ten',controller.H_ten);
route.get('/api/headline-ten',controller.find_H_ten);

route.post('/api/latest_news',controller.latest);
route.get('/api/latest',controller.find_latest);

route.post('/api/tranding',controller.trandings);
route.get('/api/trandings',controller.find_trandings);

route.put('/api/users',controller.update);
route.delete('/api/users',controller.delete);
     module.exports = route