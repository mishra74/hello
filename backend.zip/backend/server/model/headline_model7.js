const  mongoose = require('mongoose');
var schema = new mongoose.Schema({
   
headline7:{type:String
},


})
const test= mongoose.model('headline7',schema);
module.exports=test;