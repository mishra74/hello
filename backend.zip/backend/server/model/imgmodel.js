const  mongoose = require('mongoose');
var imgSchema = new mongoose.Schema({
    img:{data:Buffer,
        contentType:String

    }
});
const uploadmodel= mongoose.model('image',imgSchema);
module.exports=uploadmodel;