const  mongoose = require('mongoose');
var schema = new mongoose.Schema({
   
headline1:{type:String
},
image:{ data:Buffer,
contentType:String
}
})
const test= mongoose.model('headline1',schema);
module.exports=test;