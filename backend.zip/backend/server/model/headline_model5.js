const  mongoose = require('mongoose');
var schema = new mongoose.Schema({
   
headline5:{type:String
},


})
const test= mongoose.model('headline5',schema);
module.exports=test;