const  mongoose = require('mongoose');
var schema = new mongoose.Schema({
   
headline2:{type:String
},


})
const test= mongoose.model('headline2',schema);
module.exports=test;