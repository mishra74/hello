const  mongoose = require('mongoose');
var schema = new mongoose.Schema({
    name:{type:String,
    require:true
},

})
const test= mongoose.model('test',schema);
module.exports=test;