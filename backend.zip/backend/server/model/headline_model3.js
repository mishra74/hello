const  mongoose = require('mongoose');
var schema = new mongoose.Schema({
   
headline3:{type:String
},


})
const test= mongoose.model('headline3',schema);
module.exports=test;