const  mongoose = require('mongoose');
var schema = new mongoose.Schema({
   
headline6:{type:String
},


})
const test= mongoose.model('headline6',schema);
module.exports=test;