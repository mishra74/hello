const  mongoose = require('mongoose');
var schema = new mongoose.Schema({
   
headline8:{type:String
},


})
const test= mongoose.model('headline8',schema);
module.exports=test;