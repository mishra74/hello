const  mongoose = require('mongoose');
var schema = new mongoose.Schema({
    tranding:{type:String,
    require:true
}

})
const test= mongoose.model('tranding_news',schema);
module.exports=test;