const  mongoose = require('mongoose');
var schema = new mongoose.Schema({
   
headline10:{type:String
},


})
const test= mongoose.model('headline10',schema);
module.exports=test;