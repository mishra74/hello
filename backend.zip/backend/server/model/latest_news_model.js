const  mongoose = require('mongoose');
var schema = new mongoose.Schema({
    latest:{type:String,
    require:true
},

})
const test= mongoose.model('latest_news',schema);
module.exports=test;