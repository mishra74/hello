const  mongoose = require('mongoose');
var schema = new mongoose.Schema({
   
headline9:{type:String
},


})
const test= mongoose.model('headline9',schema);
module.exports=test;