//const Userdb = require('../model/model');
var myUser=require('../model/model');
var headline=require('../model/headline_model');
var headline2=require('../model/headline_model2');
var headline3=require('../model/headline_model3');
var headline4=require('../model/headline_model4');
var headline5=require('../model/headline_model5');
var headline6=require('../model/headline_model6');
var headline7=require('../model/headline_model7');
var headline8=require('../model/headline_model8');
var headline9=require('../model/headline_model9');
var headline10=require('../model/headline_model10');
var trandings=require('../model/tranding_model');
var latest=require('../model/latest_news_model');
var image = require('../model/imgmodel');
var multer = require('multer');



exports.create=(req,res)=>{
    if(!req.body){
      res.status(400).send({message:"content can not be empty"});
        return;
    }
    const user=new myUser({
        name:req.body.name,
    })
    user
    .save(user)
    .then(data=>{
        res.send(data)})
    .catch(err=>{
        res.status(500).send({
       message:err.message||'some err accur'});
 })
}

//  headline    
//image headline
// storage
const Storage = multer.diskStorage({
	destination:"image",
	
	filename: function (req, file, cb) {
    cb(null, file.fieldname + "_" + Date.now()+file.originalname);
	
	
  }
})
const upload = multer({
storage:Storage}).single('image')
	

exports.H_one=(req,res)=>{
	upload(req, res, (err) =>{
    if(err){
     console.log(err);
    }
    else{const user=new headline({
        headline1:req.body.headline1,
		image:{
			data:req.file?.path,
		contentType:'image/png'}
		
    })
    user
    .save(user)
    .then(data=>{
        res.send(data)})
    .catch(err=>{
        res.status(500).send({
       message:err.message||'some err accur'});
	})}
	console.log(req.file)
})
}
exports.H_two=(req,res)=>{
    if(!req.body){
      res.status(400).send({message:"content can not be empty"});
        return;
    }
    const user=new headline2({
        headline1:req.body.headline1,
    })
    user
    .save(user)
    .then(data=>{
        res.send(data)})
    .catch(err=>{
        res.status(500).send({
       message:err.message||'some err accur'});
 })
}
exports.H_three=(req,res)=>{
    if(!req.body){
      res.status(400).send({message:"content can not be empty"});
        return;
    }
    const user=new headline3({
        headline1:req.body.headline1,
    })
    user
    .save(user)
    .then(data=>{
        res.send(data)})
    .catch(err=>{
        res.status(500).send({
       message:err.message||'some err accur'});
 })
}
exports.H_four=(req,res)=>{
    if(!req.body){
      res.status(400).send({message:"content can not be empty"});
        return;
    }
    const user=new headline4({
        headline4:req.body.headline4,
    })
    user
    .save(user)
    .then(data=>{
        res.send(data)})
    .catch(err=>{
        res.status(500).send({
       message:err.message||'some err accur'});
 })
}

exports.H_five=(req,res)=>{
    if(!req.body){
      res.status(400).send({message:"content can not be empty"});
        return;
    }
    const user=new headline5({
        headline5:req.body.headline5,
    })
    user
    .save(user)
    .then(data=>{
        res.send(data)})
    .catch(err=>{
        res.status(500).send({
       message:err.message||'some err accur'});
 })
}

exports.H_six=(req,res)=>{
    if(!req.body){
      res.status(400).send({message:"content can not be empty"});
        return;
    }
    const user=new headline6({
        headline6:req.body.headline6,
    })
    user
    .save(user)
    .then(data=>{
        res.send(data)})
    .catch(err=>{
        res.status(500).send({
       message:err.message||'some err accur'});
 })
}

exports.H_seven=(req,res)=>{
    if(!req.body){
      res.status(400).send({message:"content can not be empty"});
        return;
    }
    const user=new headline7({
        headline7:req.body.headline7,
    })
    user
    .save(user)
    .then(data=>{
        res.send(data)})
    .catch(err=>{
        res.status(500).send({
       message:err.message||'some err accur'});
 })
}

exports.H_eight=(req,res)=>{
    if(!req.body){
      res.status(400).send({message:"content can not be empty"});
        return;
    }
    const user=new headline8({
        headline8:req.body.headline8,
    })
    user
    .save(user)
    .then(data=>{
        res.send(data)})
    .catch(err=>{
        res.status(500).send({
       message:err.message||'some err accur'});
 })
}

exports.H_nine=(req,res)=>{
    if(!req.body){
      res.status(400).send({message:"content can not be empty"});
        return;
    }
    const user=new headline9({
        headline9:req.body.headline9,
    })
    user
    .save(user)
    .then(data=>{
        res.send(data)})
    .catch(err=>{
        res.status(500).send({
       message:err.message||'some err accur'});
 })
}

exports.H_ten=(req,res)=>{
    if(!req.body){
      res.status(400).send({message:"content can not be empty"});
        return;
    }
    const user=new headline10({
        headline10:req.body.headline10,
    })
    user
    .save(user)
    .then(data=>{
        res.send(data)})
    .catch(err=>{
        res.status(500).send({
       message:err.message||'some err accur'});
 })
}




// review headline
exports.find_H_one=(req,res)=>{
    console.log("abcddgg")
     headline.find()
     .then(user=>{
        console.log("12345",user)
         res.send(user)
     })
     .catch(err=>{
        console.log("catch err",err)
         res.status(500).send({message:err.message||"Error"})
     })
    }
exports.find_H_two=(req,res)=>{
    console.log("abcddgg")
     headline2.find()
     .then(user=>{
        console.log("12345",user)
         res.send(user)
     })
     .catch(err=>{
        console.log("catch err",err)
         res.status(500).send({message:err.message||"Error"})
     })
    }
exports.find_H_three=(req,res)=>{
    console.log("abcddgg")
     headline3.find()
     .then(user=>{
        console.log("12345",user)
         res.send(user)
     })
     .catch(err=>{
        console.log("catch err",err)
         res.status(500).send({message:err.message||"Error"})
     })
    }

exports.find_H_four=(req,res)=>{
    console.log("abcddgg")
     headline4.find()
     .then(user=>{
        console.log("12345",user)
         res.send(user)
     })
     .catch(err=>{
        console.log("catch err",err)
         res.status(500).send({message:err.message||"Error"})
     })
    }

exports.find_H_five=(req,res)=>{
    console.log("abcddgg")
     headline5.find()
     .then(user=>{
        console.log("12345",user)
         res.send(user)
     })
     .catch(err=>{
        console.log("catch err",err)
         res.status(500).send({message:err.message||"Error"})
     })
    }

exports.find_H_six=(req,res)=>{
    console.log("abcddgg")
     headline6.find()
     .then(user=>{
        console.log("12345",user)
         res.send(user)
     })
     .catch(err=>{
        console.log("catch err",err)
         res.status(500).send({message:err.message||"Error"})
     })
    }

exports.find_H_seven=(req,res)=>{
    console.log("abcddgg")
     headline7.find()
     .then(user=>{
        console.log("12345",user)
         res.send(user)
     })
     .catch(err=>{
        console.log("catch err",err)
         res.status(500).send({message:err.message||"Error"})
     })
    }
	
	exports.find_H_eight=(req,res)=>{
    console.log("abcddgg")
     headline8.find()
     .then(user=>{
        console.log("12345",user)
         res.send(user)
     })
     .catch(err=>{
        console.log("catch err",err)
         res.status(500).send({message:err.message||"Error"})
     })
    }
	
	exports.find_H_nine=(req,res)=>{
    console.log("abcddgg")
     headline9.find()
     .then(user=>{
        console.log("12345",user)
         res.send(user)
     })
     .catch(err=>{
        console.log("catch err",err)
         res.status(500).send({message:err.message||"Error"})
     })
    }
	
	exports.find_H_ten=(req,res)=>{
    console.log("abcddgg")
     headline10.find()
     .then(user=>{
        console.log("12345",user)
         res.send(user)
     })
     .catch(err=>{
        console.log("catch err",err)
         res.status(500).send({message:err.message||"Error"})
     })
    }




// trandings
exports.trandings=(req,res)=>{
    if(!req.body){
      res.status(400).send({message:"content can not be empty"});
        return;
    }
    const user=new trandings({
        tranding:req.body.tranding,
    })
    user
    .save(user)
    .then(data=>{
        res.send(data)})
    .catch(err=>{
        res.status(500).send({
       message:err.message||'some err accur'});
 })
}
// review trandings
exports.find_trandings=(req,res)=>{
    console.log("abcddgg")
     trandings.find()
     .then(user=>{
        console.log("12345",user)
         res.send(user)
     })
     .catch(err=>{
        console.log("catch err",err)
         res.status(500).send({message:err.message||"Error"})
     })}
 




// latest insert
exports.latest=(req,res)=>{
    if(!req.body){
      res.status(400).send({message:"content can not be empty"});
        return;
    }
    const user=new latest({
        latest:req.body.latest,
    
    })
    user
    .save(user)
    .then(data=>{
        res.send(data)})
    .catch(err=>{
        res.status(500).send({
       message:err.message||'some err accur'});
 })
}

// review latest
exports.find_latest=(req,res)=>{
    console.log("abcddgg")
     latest.find()
     .then(user=>{
        console.log("12345",user)
         res.send(user)
     })
     .catch(err=>{
        console.log("catch err",err)
         res.status(500).send({message:err.message||"Error"})
     })}
 
    

// review
exports.find=(req,res)=>{
   console.log("abcddgg")
   myUser.find()
    .then(user=>{
       console.log("12345",user)
        res.send(user)
    })
    .catch(err=>{
       console.log("catch err",err)
        res.status(500).send({message:err.message||"Error"})
    })}

//view image
exports.find_image=(req,res)=>{
    console.log("abcddgg")
    image.find()
    .then(user=>{
       console.log("12345",user)
	   Window.alert(user);
        res.send('http://localhost:3000/message-upload-for-sixth-headlines')
    })
    .catch(err=>{
       console.log("catch err",err)
        res.status(500).send({message:err.message||"Error"})
    })};
    





    // vidate request
//update
exports.update=(req,res)=>{

}
//delete
exports.delete=(req,res)=>
{

}
